<template>
  <div class="home">
    <h1>This is the homepage</h1>
   

  </div>
</template>